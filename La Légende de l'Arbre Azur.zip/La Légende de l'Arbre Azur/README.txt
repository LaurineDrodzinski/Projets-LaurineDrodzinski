Ouvrir "ProjetFinal" sur Google Chrome.

D�placement: avec les fl�ches